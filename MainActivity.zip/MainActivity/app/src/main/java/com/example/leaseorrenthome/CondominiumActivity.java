package com.example.leaseorrenthome;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class CondominiumActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_condominium);
    }
}
