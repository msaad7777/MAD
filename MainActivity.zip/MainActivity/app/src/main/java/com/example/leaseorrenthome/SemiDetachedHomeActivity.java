package com.example.leaseorrenthome;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class SemiDetachedHomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semi_detached_home);
    }
}
