package com.example.leaseorrenthome;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.leaseorrenthome.R;

public class ApartmentActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apartment); // Ensure you have activity_apartment.xml in res/layout
    }
}
